// Base URL RELATIVA SOLICITADA: Para acceder a Servidor/php desde Local/app/js
const baseUrl = '../../Servidor/php/';

const username = sessionStorage.getItem('username');
const welcomeEl = document.getElementById('welcomeUser');
const statusEl = document.getElementById('status');

const setupStep = document.getElementById('setupStep');
const verificationStep = document.getElementById('verificationStep');
const generateBtn = document.getElementById('generateBtn');
const confirmBtn = document.getElementById('confirmBtn');
const cancelBtn = document.getElementById('cancelBtn');

const qrImage = document.getElementById('qrImage');
const manualSecret = document.getElementById('manualSecret');
const totpInput = document.getElementById('totpInput');

let currentNewSecret = null; // Almacena el secreto generado temporalmente

// Comprobación inicial
if (!username) {
    statusEl.textContent = '❌ Error: No se ha encontrado el nombre de usuario en la sesión.';
    statusEl.style.color = 'red';
    // Redirigir si no hay sesión
    setTimeout(() => window.location.href = 'index.html', 1000); 
    
} else {
    welcomeEl.textContent = `Usuario: ${username}`;
}

// --- Manejadores de Eventos ---

// 1. Generar el secreto
generateBtn.addEventListener('click', async () => {
    statusEl.textContent = '⏳ Generando secreto y QR...';
    statusEl.style.color = 'orange';
    generateBtn.disabled = true;

    try {
        const formData = new FormData();
        formData.append('action', 'generate');
        formData.append('username', username);

        // Usa la ruta relativa
        const response = await fetch(baseUrl + '2fa.php', {
            method: 'POST',
            body: formData
        });

        const text = await response.text();
        
        if (response.ok && text.startsWith('GENERATE_SUCCESS:')) {
            // El servidor devuelve "GENERATE_SUCCESS:SECRETO:DATA_URI_COMPLETA"
            const parts = text.split(':');
            
            if (parts.length >= 3) {
                 const secret = parts[1];
                 
                 // CORRECCIÓN CLAVE: Unimos las partes restantes (índices 2 en adelante)
                 // para reconstruir el Data URI completo (que contiene "data:image/png;base64,..." y más ':')
                 const dataUri = parts.slice(2).join(':'); 
            
                 currentNewSecret = secret;
                 
                 qrImage.src = dataUri; // Asignamos el Data URI completo
                 manualSecret.textContent = secret;
                 
                 setupStep.style.display = 'none';
                 verificationStep.style.display = 'block';
                 statusEl.textContent = '✅ Código QR generado. ¡Escanea y confirma!';
                 statusEl.style.color = 'green';
             } else {
                 statusEl.textContent = `❌ Error de formato en la respuesta del servidor: ${text}`;
                 statusEl.style.color = 'red';
             }

        } else {
            statusEl.textContent = `❌ Error al generar el 2FA: ${text}`;
            statusEl.style.color = 'red';
        }

    } catch (err) {
        statusEl.textContent = '❌ Error de red durante la generación: ' + err.message;
        statusEl.style.color = 'red';
    } finally {
        generateBtn.disabled = false;
    }
});

// 2. Confirmar el código TOTP y guardar el secreto 
confirmBtn.addEventListener('click', async () => {
    const totpCode = totpInput.value.trim();
    
    if (totpCode.length !== 6 || !/^\d+$/.test(totpCode)) {
        statusEl.textContent = '⚠️ Por favor, introduce un código de 6 dígitos válido.';
        statusEl.style.color = 'red';
        return;
    }

    if (!currentNewSecret) {
        statusEl.textContent = '❌ Error: El secreto no ha sido generado. Inténtalo de nuevo.';
        statusEl.style.color = 'red';
        return;
    }

    statusEl.textContent = '⏳ Verificando código y activando 2FA...';
    statusEl.style.color = 'orange';
    confirmBtn.disabled = true;
    
    try {
        const formData = new FormData();
        formData.append('action', 'confirm_setup');
        // Enviamos el USERNAME para que PHP pueda obtener el ID
        formData.append('username', username); 
        formData.append('new_secret', currentNewSecret);
        formData.append('totp_code', totpCode);

        const response = await fetch(baseUrl + '2fa.php', {
            method: 'POST',
            body: formData
        });

        const text = await response.text();
        
        if (response.ok && text.startsWith('CONFIRM_SUCCESS:')) {
            statusEl.textContent = '✅ ' + text.split(':')[1];
            statusEl.style.color = 'green';
            
            setTimeout(() => {
                window.location.href = 'dashboard.html';
            }, 1500);

        } else {
            statusEl.textContent = '❌ ' + (text.split(':')[1] || 'Error de verificación.');
            statusEl.style.color = 'red';
            totpInput.value = '';
            confirmBtn.disabled = false; 
        }

    } catch (err) {
        statusEl.textContent = '❌ Error de red durante la confirmación: ' + err.message;
        statusEl.style.color = 'red';
    } finally {
        confirmBtn.disabled = false;
    }
});

// 3. Botón Cancelar
cancelBtn.addEventListener('click', () => {
    window.location.href = 'dashboard.html';
});