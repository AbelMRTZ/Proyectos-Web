document.addEventListener('DOMContentLoaded', () => {
  console.log('[dashboard.js] versión share1 cargada');
  let decrypting = false;
  const username = sessionStorage.getItem('username');
  const password = sessionStorage.getItem('password');
  const welcomeEl = document.getElementById('welcomeUser');
  const fileCountEl = document.getElementById('fileCount');
  const fileListEl = document.getElementById('fileList');
  const statusEl = document.getElementById('status');

  if (!username || !password) {
    alert("⚠️ Por favor, inicia sesión primero.");
    window.location.href = "index.html";
    return;
  }

  welcomeEl.textContent = username;

  // --- Controles del modal ---
  const modal = document.getElementById('fileModal');
  const encryptBtn = document.getElementById('encryptBtn');
  const closeModalBtn = document.getElementById('closeModalBtn');
  const confirmEncryptBtn = document.getElementById('confirmEncryptBtn');
  const fileInput = document.getElementById('fileInput');

  encryptBtn.onclick = () => {
    modal.style.display = "flex";
    fileInput.value = "";
  };

  closeModalBtn.onclick = () => {
    modal.style.display = "none";
  };
  
  // --- UI ligera para compartir con datalist (usa cargarUsuariosDatalist + usuarios.php) ---
  const shareUI = (() => {
    let overlay, box, title, fileNameEl, input, dataList, confirmBtn, cancelBtn, inlineStatus;
    let currentFile = null;

    function ensureBuilt() {
      if (overlay) return;
      overlay = document.createElement('div');
      overlay.style.cssText = 'display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:9999;align-items:center;justify-content:center;';

      box = document.createElement('div');
      box.style.cssText = 'background:#1e293b;color:#e2e8f0;width:420px;max-width:95vw;border-radius:12px;padding:16px;box-shadow:0 10px 30px rgba(0,0,0,.4);';

      title = document.createElement('h3');
      title.textContent = 'Compartir archivo';
      title.style.margin = '0 0 8px 0';

      fileNameEl = document.createElement('p');
      fileNameEl.style.cssText = 'opacity:.85;margin:0 0 10px 0;';

      input = document.createElement('input');
      input.type = 'text';
      input.id = 'shareUsernameInput';
      input.placeholder = 'Usuario destinatario';
      input.setAttribute('list', 'usersDatalist');
      input.style.cssText = 'width:100%;padding:10px;border-radius:8px;border:1px solid #334155;background:#0f172a;color:#e2e8f0;outline:none;';

      // Crear datalist global si no existe
      dataList = document.getElementById('usersDatalist');
      if (!dataList) {
        dataList = document.createElement('datalist');
        dataList.id = 'usersDatalist';
        document.body.appendChild(dataList);
      }

      const btnRow = document.createElement('div');
      btnRow.style.cssText = 'display:flex;gap:10px;justify-content:center;margin-top:12px;';

      confirmBtn = document.createElement('button');
      confirmBtn.textContent = 'Compartir';
      confirmBtn.style.cssText = 'background:#6366f1;border:none;color:white;padding:10px 16px;border-radius:8px;cursor:pointer;';

      cancelBtn = document.createElement('button');
      cancelBtn.textContent = 'Cancelar';
      cancelBtn.style.cssText = 'background:#ef4444;border:none;color:white;padding:10px 16px;border-radius:8px;cursor:pointer;';

      inlineStatus = document.createElement('p');
      inlineStatus.style.cssText = 'margin-top:10px;color:#facc15;text-align:center;min-height:1em;';

      btnRow.appendChild(confirmBtn);
      btnRow.appendChild(cancelBtn);

      box.appendChild(title);
      box.appendChild(fileNameEl);
      box.appendChild(input);
      box.appendChild(btnRow);
      box.appendChild(inlineStatus);
      overlay.appendChild(box);
      document.body.appendChild(overlay);

      cancelBtn.onclick = close;
      overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
      document.addEventListener('keydown', (e) => { if (overlay.style.display !== 'none' && e.key === 'Escape') close(); });

      // Confirmar compartición
      confirmBtn.addEventListener('click', async () => {
        const targetUser = (input.value || '').trim();
        if (!currentFile || !targetUser) { inlineStatus.textContent = 'Ingresa un destinatario válido.'; return; }
        if (targetUser === username) { inlineStatus.textContent = 'No puedes compartir contigo mismo.'; return; }
        confirmBtn.disabled = true;
        cancelBtn.disabled = true;
        inlineStatus.textContent = `⏳ Compartiendo "${currentFile.file_name}" con ${targetUser}...`;
        try {
          const fd = new FormData();
          fd.append('file_id', currentFile.file_id);
          fd.append('source_username', username);
          fd.append('target_username', targetUser);
          fd.append('password', password);
          const resp = await fetch('../../Servidor/php/share.php', { method: 'POST', body: fd });
          const txt = await resp.text();
          let data; try { data = JSON.parse(txt); } catch { data = { error: txt }; }
          if (data && data.success) {
            inlineStatus.textContent = '✅ ' + data.message;
            setTimeout(() => { close(); }, 500);
            loadUserFiles();
          } else {
            inlineStatus.textContent = '❌ ' + (data.error || 'Error desconocido');
          }
        } catch (e) {
          inlineStatus.textContent = '❌ Error de red al compartir: ' + e.message;
        } finally {
          confirmBtn.disabled = false;
          cancelBtn.disabled = false;
        }
      });
    }

    function open(file) {
      ensureBuilt();
      currentFile = file;
      fileNameEl.textContent = file.file_name;
      input.value = '';
      inlineStatus.textContent = '';
      overlay.style.display = 'flex';
      // Poblar datalist usando tu función existente
      try { cargarUsuariosDatalist(); } catch (e) { console.warn('cargarUsuariosDatalist no disponible:', e); }
      setTimeout(() => input.focus(), 0);
    }
    function close() {
      if (!overlay) return;
      overlay.style.display = 'none';
      currentFile = null;
    }
    return { open, close };
  })();

  // --- Cargar archivos del usuario ---
  async function loadUserFiles() {
    const formData = new FormData();
    formData.append('username', username);

    try {
      const res = await fetch('../../Servidor/php/fetchFiles.php', { method: 'POST', body: formData });
      const files = await res.json();

      if (files.error) {
        fileListEl.innerHTML = `<p>❌ ${files.error}</p>`;
        return;
      }

      renderFiles(files);
    } catch (err) {
      fileListEl.innerHTML = `<p>❌ Error al cargar los archivos: ${err.message}</p>`;
    }
  }

  async function loadSharedFiles() {
    const fd = new FormData();
    let sharedEl = document.getElementById('sharedList'),
        p = document.createElement('p');

    while (sharedEl.firstChild) {
        sharedEl.removeChild(sharedEl.firstChild);
    }

    fd.append('username', username);
    try {
      const res = await fetch('../../Servidor/php/fetchShared.php', { method: 'POST', body: fd });
      const shared = await res.json();
      if(shared.length > 0){
        renderShared(shared);
      } else {
        p.textContent = '📭 No tienes archivos compartidos';
        sharedEl.appendChild(p);
      }
    } catch (e) {
      document.getElementById('sharedList').innerHTML = `<p>❌ Error al cargar compartidos: ${e.message}</p>`;
    }
  }

  // --- Encriptar nuevo archivo ---
  confirmEncryptBtn.onclick = async () => {
    const file = fileInput.files[0];
    if (!file) {
      alert("Por favor, selecciona un archivo primero.");
      return;
    }

    statusEl.textContent = "⏳ Encriptando y subiendo el archivo...";
    statusEl.style.color = "orange";
    confirmEncryptBtn.disabled = true;

    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('username', username);
      formData.append('password', password);

      const response = await fetch('../../Servidor/php/upload.php', {
        method: 'POST',
        body: formData
      });

      const text = await response.text();
      if (response.ok && text.includes("✅")) {
        statusEl.textContent = "✅ Archivo encriptado y almacenado correctamente.";
        statusEl.style.color = "green";
        modal.style.display = "none";
        loadUserFiles();
      } else {
        statusEl.textContent = "❌ " + text;
        statusEl.style.color = "red";
      }
    } catch (err) {
      statusEl.textContent = "❌ Error de red: " + err.message;
      statusEl.style.color = "red";
    } finally {
      confirmEncryptBtn.disabled = false;
    }
  };

  function renderFiles(files, sharedFilesList = []) {
    fileListEl.innerHTML = "";
    fileCountEl.textContent = `Tienes ${files.length} archivo${files.length !== 1 ? "s" : ""} encriptado${files.length !== 1 ? "s" : ""}.`;

    files.forEach(file => {
      const item = document.createElement('div');
      item.classList.add('file-item');

      // Nombre del archivo
      const span = document.createElement('span');
      span.textContent = file.file_name;
      item.appendChild(span);

      // Botón Desencriptar
      const decryptBtn = document.createElement('button');
      decryptBtn.textContent = '🔓 Desencriptar y Descargar';
      decryptBtn.dataset.id = file.file_id;
      decryptBtn.classList.add('decryptBtn');
      item.appendChild(decryptBtn);

    
      // Botón Compartir
      const shareBtn = document.createElement('button');
      shareBtn.textContent = '🤝 Compartir';
      shareBtn.dataset.id = file.file_id;
      shareBtn.classList.add('shareBtn');
      item.appendChild(shareBtn);

      // Botón Eliminar
      const deleteBtn = document.createElement('button');
      deleteBtn.textContent = '🗑 Eliminar';
      deleteBtn.dataset.id = file.file_id;
      deleteBtn.classList.add('deleteBtn');
      item.appendChild(deleteBtn);

      // Asignar eventos a los botones decrypt y delete (igual que antes)
      decryptBtn.onclick = async () => {
        if (decrypting) return;
        decrypting = true;
        decryptBtn.disabled = true;

        statusEl.textContent = `⏳ Desencriptando "${file.file_name}"...`;
        statusEl.style.color = "orange";

        try {
          const formData = new FormData();
          formData.append('file_id', file.file_id);
          formData.append('username', username);
          formData.append('password', password);

          const response = await fetch('../../Servidor/php/download.php', {
            method: 'POST',
            body: formData
          });

          const text = await response.text();

          try {
            const data = JSON.parse(text);
            if (data.success) {
              statusEl.textContent = `✅ ${data.message}`;
              statusEl.style.color = "green";
            } else {
              statusEl.textContent = "❌ " + (data.message || text);
              statusEl.style.color = "red";
            }
          } catch {
            statusEl.textContent = "❌ Error inesperado: " + text;
            statusEl.style.color = "red";
          }

        } catch (err) {
          statusEl.textContent = "❌ Error de red: " + err.message;
          statusEl.style.color = "red";
        } finally {
          decryptBtn.disabled = false;
          decrypting = false;
        }
      };   

      // shareBtn.onclick = async () => {
      //   const targetUser = prompt("Introduce el username del destinatario:");
      //   if (!targetUser) return;

      //   shareBtn.disabled = true;
      //   statusEl.textContent = `⏳ Compartiendo \"${file.file_name}\" con ${targetUser}...`;
      //   statusEl.style.color = 'orange';
      //   try {
      //     const fd = new FormData();
      //     fd.append('file_id', file.file_id);
      //     fd.append('source_username', username);
      //     fd.append('target_username', targetUser);
      //     fd.append('password', password);
      //     const resp = await fetch('../../Servidor/php/share.php', { method: 'POST', body: fd });
      //     const txt = await resp.text();
      //     let data;
      //     try { data = JSON.parse(txt); } catch { data = { error: txt }; }
      //     if (data.success) {
      //       statusEl.textContent = data.message;
      //       statusEl.style.color = 'green';
      //       // Recargar lista para reflejar que ya no está bajo el usuario origen
      //       loadUserFiles();
      //     } else {
      //       statusEl.textContent = '❌ ' + (data.error || 'Error desconocido');
      //       statusEl.style.color = 'red';
      //     }
      //   } catch (e) {
          
      //     statusEl.textContent = '❌ Error de red al compartir: ' + e.message;
      //     statusEl.style.color = 'red';
        
      //   } finally {
        
      //     shareBtn.disabled = false;
        
      //   }
      // };

      shareBtn.onclick = () => {
        shareUI.open(file);
      };

          // Eliminar archivo propio
      deleteBtn.onclick = async () => {
        if (!confirm(`¿Eliminar definitivamente "${file.file_name}"?`)) return;
        deleteBtn.disabled = true;
        statusEl.textContent = `⏳ Eliminando "${file.file_name}"...`;
        statusEl.style.color = 'orange';
        try {
          const fd = new FormData();
          fd.append('file_id', file.file_id);
          fd.append('username', username);
          fd.append('password', password);
          const resp = await fetch('../../Servidor/php/deleteFile.php', { method: 'POST', body: fd });
          const txt = await resp.text();
          let data; try { data = JSON.parse(txt); } catch { data = { error: txt }; }
          if (data.success) {
            statusEl.textContent = data.message + (data.warning ? ' ' + data.warning : '');
            statusEl.style.color = 'green';
            loadUserFiles();
          } else {
            statusEl.textContent = '❌ ' + (data.error || 'Error desconocido');
            statusEl.style.color = 'red';
          }
        } catch (e) {
          statusEl.textContent = '❌ Error de red al eliminar: ' + e.message;
          statusEl.style.color = 'red';
        } finally {
          deleteBtn.disabled = false;
        }
      };
    fileListEl.appendChild(item);
  });
  }


  function renderShared(shared) {
    console.log('creando...');
    const sharedEl = document.getElementById('sharedList');

    // 🔥 limpiar con DOM
    while (sharedEl.firstChild) {
        sharedEl.removeChild(sharedEl.firstChild);
    }

    shared.forEach(row => {

        // contenedor principal
        const div = document.createElement('div');
        div.classList.add('file-item');

        // span contenedor
        const nameSpan = document.createElement('span');
        nameSpan.textContent = row.file_name + " ";

        // small (owner)
        const small = document.createElement('small');
        small.style.opacity = ".7";
        small.textContent = `(de ${row.original_owner_username || row.original_owner || '¿owner?'})`;

        nameSpan.appendChild(small);

        // botón descargar
        const btn = document.createElement('button');
        btn.classList.add('decryptSharedBtn');
        btn.dataset.id = row.file_id;
        btn.textContent = "🔓 Descargar";

        // botón eliminar copia
        const delBtn = document.createElement('button');
        delBtn.classList.add('deleteSharedBtn');
        delBtn.dataset.id = row.file_id;
        delBtn.textContent = "🗑 Eliminar copia";

        // --- listeners exactamente como en tu código ---
        btn.onclick = async () => {
            statusEl.textContent = `⏳ Desencriptando compartido "${row.file_name}"...`;
            statusEl.style.color = 'orange';
            try {
                const fd = new FormData();
                fd.append('file_id', row.file_id);
                fd.append('username', username);
                fd.append('password', password);
                const r = await fetch('../../Servidor/php/downloadShared.php', { method: 'POST', body: fd });
                const t = await r.text();
                let data; try { data = JSON.parse(t); } catch { data = { message: t }; }
                if (data.success) {
                    statusEl.textContent = `✅ ${data.message}`;
                    statusEl.style.color = 'green';
                } else {
                    statusEl.textContent = '❌ ' + (data.message || data.error || t);
                    statusEl.style.color = 'red';
                }
            } catch (err) {
                statusEl.textContent = '❌ Error: ' + err.message;
                statusEl.style.color = 'red';
            }
        };

        delBtn.onclick = async () => {
            if (!confirm(`¿Eliminar tu copia compartida de "${row.file_name}"?`)) return;
            delBtn.disabled = true;
            statusEl.textContent = `⏳ Eliminando copia compartida "${row.file_name}"...`;
            statusEl.style.color = 'orange';
            try {
                const fd = new FormData();
                fd.append('file_id', row.file_id);
                fd.append('username', username);
                fd.append('password', password);
                const r = await fetch('../../Servidor/php/deleteFile.php', { method: 'POST', body: fd });
                const t = await r.text();
                let data; try { data = JSON.parse(t); } catch { data = { error: t }; }
                if (data.success) {
                    statusEl.textContent = data.message;
                    statusEl.style.color = 'green';
                    loadSharedFiles();
                } else {
                    statusEl.textContent = '❌ ' + (data.error || 'Error desconocido');
                    statusEl.style.color = 'red';
                }
            } catch (e) {
                statusEl.textContent = '❌ Error de red al eliminar copia: ' + e.message;
                statusEl.style.color = 'red';
            } finally {
                delBtn.disabled = false;
            }
        };

        // ensamblar DOM
        div.appendChild(nameSpan);
        div.appendChild(btn);
        div.appendChild(delBtn);

        sharedEl.appendChild(div);
    });

    console.log('[dashboard] compartidos renderizados:', shared.length);
  }

  // --- Carga inicial ---
  loadUserFiles();
  loadSharedFiles();
});



function cargarUsuariosDatalist() {
    const datalist = document.getElementById("usersDatalist");
    const usuarioLogueado = sessionStorage.getItem("username"); // usuario logueado

    const xhr = new XMLHttpRequest();
  xhr.open("GET", "../../Servidor/php/usuarios.php", true);

    xhr.onload = function () {
        if (xhr.status === 200) {
            try {
                const response = JSON.parse(xhr.responseText);

                if (!response.success) {
                    console.error("Error en usuarios.php:", response.message);
                    return;
                }

                // Limpiar datalist
                datalist.textContent = "";

                response.usernames.forEach(usuario => {
                    if (usuario !== usuarioLogueado) {  // Excluir al usuario logueado
                        const option = document.createElement("option");
                        option.value = usuario;
                        datalist.appendChild(option);
                    }
                });

            } catch (error) {
                console.error("Error al procesar JSON de usuarios:", error);
            }
        }
    };

    xhr.onerror = function () {
        console.error("Error en la petición AJAX a usuarios.php");
    };

    xhr.send();
}