document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('encryptForm');
    const loginBtn = document.getElementById('loginBtn');
    const registerBtn = document.getElementById('registerBtn');
    const statusEl = document.getElementById('status');

    if (!form || !loginBtn || !statusEl) {
        console.error("❌ ERROR CRÍTICO: Faltan elementos en el DOM.");
        return;
    }

    if (registerBtn) {
        registerBtn.addEventListener('click', () => {
            window.location.href = 'register.html';
        });
    }

    const totpContainer = document.createElement('div');
    totpContainer.id = 'totp-container';
    totpContainer.style.display = 'none';
    totpContainer.style.marginTop = '15px';
    totpContainer.innerHTML = `
        <label for="totpInput" style="font-weight:bold; color:#333; display:block; margin-bottom:5px;">Código de Verificación (Google Auth):</label>
        <input type="text" id="totpInput" placeholder="Introduce los 6 dígitos" maxlength="6" autocomplete="off" style="width: 100%; padding: 8px; box-sizing: border-box;">
    `;

    form.insertBefore(totpContainer, loginBtn);

    // Variables de estado
    let is2FARequired = false;
    let tempUserId = null;
    let tempUsername = null;
    let tempPassword = null; 

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const usernameInput = document.getElementById('usernameInput');
        const passwordInput = document.getElementById('passwordInput');
        
        const usernameLabel = document.querySelector('label[for="usernameInput"]');
        const passwordLabel = document.querySelector('label[for="passwordInput"]');

        // verificacion del codigo 2FA
        if (is2FARequired) {
            const totpInput = document.getElementById('totpInput');
            const code = totpInput ? totpInput.value.trim() : '';
            
            if (code.length < 6) {
                updateStatus('⚠️ Introduce el código de 6 dígitos.', 'orange');
                return;
            }
            verify2FA(code);
            return;
        }

        // login normal
        if (!usernameInput || !passwordInput) {
            updateStatus('❌ Error: No se encuentran los campos.', 'red');
            return;
        }

        const username = usernameInput.value.trim();
        const password = passwordInput.value;

        if (!username || !password) {
            updateStatus('⚠️ Completa todos los campos.', 'orange');
            return;
        }

        updateStatus('⏳ Verificando credenciales...', 'orange');
        loginBtn.disabled = true;

        try {
            const formData = new FormData();
            formData.append('username', username);
            formData.append('password', password);

            const response = await fetch('../../Servidor/php/login.php', {
                method: 'POST',
                body: formData
            });
            
            const text = await response.text();
            
            if (text.trim().startsWith('<')) {
                throw new Error("Error del servidor (404/500). Revisa las rutas.");
            }

            // credenciales ok pero requiere 2FA
            if (text.startsWith('2FA_REQUIRED:')) {
                const parts = text.split(':');
                tempUserId = parts[1];
                tempUsername = parts[2];
                tempPassword = password; 

                is2FARequired = true;

                // Ocultamos todo lo del login nor
                safeHide(usernameInput);
                safeHide(passwordInput);
                safeHide(usernameLabel);
                safeHide(passwordLabel);
                safeHide(registerBtn); 

                // Mostramos 2FA
                totpContainer.style.display = 'block'; 
                
                const input2fa = document.getElementById('totpInput');
                if (input2fa) input2fa.focus();
                
                loginBtn.textContent = 'Verificar Código';
                updateStatus('🔐 Introduce el código de tu aplicación autenticadora.', 'blue');
                loginBtn.disabled = false;
            } 
            // Login exitoso SIN 2FA
            else if (text.includes('✅')) {
                finalizeLogin(username, password);
            }

            else {
                updateStatus(text, 'red');
                loginBtn.disabled = false;
            }

        } catch (err) {
            console.error(err);
            updateStatus('❌ Error: ' + err.message, 'red');
            loginBtn.disabled = false;
        }
    });

    function safeHide(element) {
        if (element && element.style) {
            element.style.display = 'none';
        }
    }

    function updateStatus(msg, color) {
        if (statusEl) {
            statusEl.textContent = msg;
            statusEl.style.color = color;
        }
    }

    async function verify2FA(code) {
        updateStatus('⏳ Validando código...', 'orange');
        loginBtn.disabled = true;

        try {
            const formData = new FormData();
            formData.append('action', 'verify');
            formData.append('user_id', tempUserId);
            formData.append('totp_code', code);

            const response = await fetch('../../Servidor/php/2fa.php', {
                method: 'POST',
                body: formData
            });

            const text = await response.text();

            if (text.startsWith('VERIFICATION_SUCCESS:')) {
                finalizeLogin(tempUsername, tempPassword);
            } else {
                updateStatus('❌ Código incorrecto o expirado.', 'red');
                loginBtn.disabled = false;
                const input2fa = document.getElementById('totpInput');
                if (input2fa) input2fa.value = '';
            }
        } catch (err) {
            updateStatus('❌ Error al validar 2FA: ' + err.message, 'red');
            loginBtn.disabled = false;
        }
    }

    function finalizeLogin(user, pass) {
        updateStatus('✅ Acceso concedido. Redirigiendo...', 'green');
        sessionStorage.setItem('username', user);
        sessionStorage.setItem('password', pass);
        
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1000);
    }
});