document.getElementById('registerForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;
  const statusEl = document.getElementById('status');
  const registerBtn = document.getElementById('registerBtn');

  if (!username || !password) {
    statusEl.textContent = "⚠️ Por favor, completa todos los campos.";
    statusEl.style.color = "red";
    return;
  }

  registerBtn.disabled = true;
  statusEl.textContent = "⏳ Creando tu cuenta...";
  statusEl.style.color = "orange";

  try {
    const formData = new FormData();
    formData.append('username', username);
    formData.append('password', password);

    const response = await fetch('../../Servidor/php/register.php', {
      method: 'POST',
      body: formData
    });

    const text = await response.text();
    if (response.ok && text.includes("✅")) {
      statusEl.textContent = "✅ Cuenta creada correctamente.";
      statusEl.style.color = "green";

      // Guardar credenciales en sessionStorage y redirigir al panel
      sessionStorage.setItem('username', username);
      sessionStorage.setItem('password', password);

      setTimeout(() => window.location.href = "dashboard.html", 1200);
    } else {
      statusEl.textContent = "❌ " + text;
      statusEl.style.color = "red";
    }
  } catch (err) {
    statusEl.textContent = "❌ Error de red: " + err.message;
    statusEl.style.color = "red";
  } finally {
    registerBtn.disabled = false;
  }
});
