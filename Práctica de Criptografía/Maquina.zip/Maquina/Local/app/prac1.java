import javax.crypto.*;
import javax.crypto.spec.*;
import java.io.*;
import java.security.*;
import java.security.spec.*;
import java.util.Base64;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

public class prac1 {

    // ================================
    // AES ENCRIPTAR/DESENCRIPTAR
    // ================================
    public static byte[] encryptAES(byte[] data, SecretKey key) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        byte[] iv = new byte[12];
        new SecureRandom().nextBytes(iv);
        GCMParameterSpec spec = new GCMParameterSpec(128, iv);
        cipher.init(Cipher.ENCRYPT_MODE, key, spec);
        byte[] enc = cipher.doFinal(data);

        byte[] out = new byte[iv.length + enc.length];
        System.arraycopy(iv, 0, out, 0, iv.length);
        System.arraycopy(enc, 0, out, iv.length, enc.length);
        return out;
    }

    public static byte[] decryptAES(byte[] cipherData, SecretKey key) throws Exception {
        byte[] iv = new byte[12];
        System.arraycopy(cipherData, 0, iv, 0, 12);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, iv));
        return cipher.doFinal(cipherData, 12, cipherData.length - 12);
    }

    // ================================
    // GENERACION DE SALT + CLAVE
    // ================================
    public static SecretKey generateRandomKey() throws Exception {
        KeyGenerator keygen = KeyGenerator.getInstance("AES");
        keygen.init(256);
        return keygen.generateKey();
    }

    public static byte[] generateSalt() {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        return salt;
    }

    public static byte[] pbkdf2(char[] password, byte[] salt, int iterations, int keyLenBits) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(password, salt, iterations, keyLenBits);
        SecretKeyFactory skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        byte[] res = skf.generateSecret(spec).getEncoded();
        spec.clearPassword();
        return res;
    }

    public static byte[] readFileToBytes(String filePath) throws IOException {
        File file = new File(filePath);
        byte[] fileBytes = new byte[(int) file.length()];
        try (FileInputStream fis = new FileInputStream(file)) {
            if (fis.read(fileBytes) != fileBytes.length)
                throw new IOException("Could not read entire file");
        }
        return fileBytes;
    }

    // ================================
    // ================================
    // INICIO DE MÉTODOS AÑADIDOS PARA FIRMA DIGITAL
    // ================================
    // ================================

    // Método para generar la firma digital de un archivo y timestamp
    public static String signFile(byte[] fileData, PrivateKey privKey, String timestamp) throws Exception {
        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initSign(privKey);

        // Concatenar datos + timestamp
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        baos.write(fileData);
        baos.write(timestamp.getBytes("UTF-8"));
        byte[] dataToSign = baos.toByteArray();

        signature.update(dataToSign);
        byte[] digitalSignature = signature.sign();
        return Base64.getEncoder().encodeToString(digitalSignature);
    }

    // Método para generar timestamp UTC en formato legible
    public static String generateTimestamp() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
                .withZone(ZoneOffset.UTC);
        return formatter.format(Instant.now());
    }

    public static boolean verifySign(PublicKey senderPub, String timestamp, String signatureB64, byte[] fileData) throws Exception{
        Signature sig = Signature.getInstance("SHA256withRSA");
        sig.initVerify(senderPub);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        baos.write(fileData);
        baos.write(timestamp.getBytes("UTF-8"));
        sig.update(baos.toByteArray());

        return sig.verify(Base64.getDecoder().decode(signatureB64));
    }
    // ================================
    // FIN DE MÉTODOS DE FIRMA DIGITAL
    // ================================

    // ================================
    // MAIN
    // ================================
    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            System.err.println("Usage: java prac1 <mode> ...");
            return;
        }

        String mode = args[0].toLowerCase();

        // MODO REGISTRARSE
        if (mode.equals("register")) {
            if (args.length != 2) {
                System.err.println("Usage: java prac1 register <password>");
                return;
            }

            String password = args[1];
            byte[] salt = generateSalt();
            byte[] passwordHash = pbkdf2(password.toCharArray(), salt, 200000, 256);
            SecretKeySpec passwordKey = new SecretKeySpec(passwordHash, "AES");

            KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
            kpg.initialize(2048);
            KeyPair kp = kpg.generateKeyPair();
            PublicKey pub = kp.getPublic();
            PrivateKey priv = kp.getPrivate();

            byte[] encryptedPrivKeyBytes = encryptAES(priv.getEncoded(), passwordKey);

            String jsonOutput = "{"
                    + "\"salt\":\"" + Base64.getEncoder().encodeToString(salt) + "\","
                    + "\"passwordHash\":\"" + Base64.getEncoder().encodeToString(passwordHash) + "\","
                    + "\"encryptedPrivateKey\":\"" + Base64.getEncoder().encodeToString(encryptedPrivKeyBytes) + "\","
                    + "\"publicKey\":\"" + Base64.getEncoder().encodeToString(pub.getEncoded()) + "\""
                    + "}";
            System.out.println(jsonOutput);
            return;
        }

        // MODO ENCRIPTAR (usuario ya registrado)
        if (mode.equals("encrypt")) {
            if (args.length != 6) {
                System.err.println("Usage: java prac1 encrypt <filePath> <password> <pubKey> <salt> <encPrivKey>");
                return;
            }

            String filePath = args[1];
            String password = args[2];
            String pubB64 = args[3];
            String saltB64 = args[4];
            String encPrivB64 = args[5];

            // cargar credenciales de usuario
            byte[] salt = Base64.getDecoder().decode(saltB64);
            byte[] passwordHash = pbkdf2(password.toCharArray(), salt, 200000, 256);
            SecretKeySpec passwordKey = new SecretKeySpec(passwordHash, "AES");

            byte[] encryptedPrivBytes = Base64.getDecoder().decode(encPrivB64);
            byte[] privBytes = decryptAES(encryptedPrivBytes, passwordKey);

            KeyFactory kf = KeyFactory.getInstance("RSA");
            PKCS8EncodedKeySpec privSpec = new PKCS8EncodedKeySpec(privBytes);
            PrivateKey priv = kf.generatePrivate(privSpec);

            byte[] pubBytes = Base64.getDecoder().decode(pubB64);
            X509EncodedKeySpec pubSpec = new X509EncodedKeySpec(pubBytes);
            PublicKey pub = kf.generatePublic(pubSpec);

            // Encriptar fichero
            SecretKey aesKey = generateRandomKey();
            byte[] fileData = readFileToBytes(filePath);
            byte[] encryptedFile = encryptAES(fileData, aesKey);

            // encriptar clave AES con clave publica RSA
            Cipher rsaCipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
            rsaCipher.init(Cipher.ENCRYPT_MODE, pub);
            byte[] encryptedAESKey = rsaCipher.doFinal(aesKey.getEncoded());

            // ================================
            // AÑADIDO: GENERAR TIMESTAMP Y FIRMA DIGITAL
            // ================================
            String timestamp = generateTimestamp();
            String digitalSignatureB64 = signFile(fileData, priv, timestamp);
            // ================================

            // output JSON
            String jsonOutput = "{"
                    + "\"salt\":\"" + Base64.getEncoder().encodeToString(salt) + "\","
                    + "\"passwordHash\":\"" + Base64.getEncoder().encodeToString(passwordHash) + "\","
                    + "\"aesKey\":\"" + Base64.getEncoder().encodeToString(encryptedAESKey) + "\","
                    + "\"encryptedPrivateKey\":\"" + Base64.getEncoder().encodeToString(encryptedPrivBytes) + "\","
                    + "\"encryptedFile\":\"" + Base64.getEncoder().encodeToString(encryptedFile) + "\","
                    + "\"publicKey\":\"" + Base64.getEncoder().encodeToString(pub.getEncoded()) + "\","
                    + "\"firmaDigitalB64\":\"" + digitalSignatureB64 + "\","
                    + "\"firmaTimestamp\":\"" + timestamp + "\""
                    + "}";
            System.out.println(jsonOutput);
            return;
        }

        // MODO DESENCRIPTAR
        if (mode.equals("decrypt")) {
            if (args.length != 7) {
                System.err.println(
                        "Usage: java prac1 decrypt <encryptedFilePath> <password> <aesKeyEncrypted> <pubKey> <salt> <encPrivKey>");
                return;
            }

            String filePath = args[1];
            String password = args[2];
            String aesKeyEncB64 = args[3];
            String pubB64 = args[4];
            String saltB64 = args[5];
            String encPrivB64 = args[6];

            byte[] salt = Base64.getDecoder().decode(saltB64);
            byte[] passwordHash = pbkdf2(password.toCharArray(), salt, 200000, 256);
            SecretKeySpec passwordKey = new SecretKeySpec(passwordHash, "AES");

            byte[] encPrivBytes = Base64.getDecoder().decode(encPrivB64);
            byte[] privBytes = decryptAES(encPrivBytes, passwordKey);
            KeyFactory kf = KeyFactory.getInstance("RSA");
            PKCS8EncodedKeySpec privSpec = new PKCS8EncodedKeySpec(privBytes);
            PrivateKey priv = kf.generatePrivate(privSpec);

            byte[] aesKeyEnc = Base64.getDecoder().decode(aesKeyEncB64);
            Cipher rsaCipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
            rsaCipher.init(Cipher.DECRYPT_MODE, priv);
            byte[] aesKeyBytes = rsaCipher.doFinal(aesKeyEnc); 
            SecretKeySpec aesKey = new SecretKeySpec(aesKeyBytes, "AES");

            byte[] encryptedFile = readFileToBytes(filePath);
            byte[] decryptedFile = decryptAES(encryptedFile, aesKey);

            System.out.println("{\"decryptedFile\":\"" + Base64.getEncoder().encodeToString(decryptedFile) + "\"}");
            return;
        }
        
        // MODO SHARE (re-encriptar clave AES para nuevo propietario)
        // Uso: java prac1 share <encryptedAESKeyBase64> <password> <saltBase64> <encryptedPrivateKeyBase64> <recipientPubKeyBase64>
        // Flujo:
        // 1. Deriva passwordHash con PBKDF2.
        // 2. Descifra la clave privada del usuario emisor.
        // 3. Descifra la clave AES (encryptedAESKey) con la clave privada.
        // 4. Cifra esa clave AES con la clave pública del destinatario.
        // 5. Devuelve JSON con aesKeyReEncrypted.
        // if (mode.equals("share")) {
        //     if (args.length != 6) {
        //         System.err.println("Usage: java prac1 share <encryptedAESKeyBase64> <password> <saltBase64> <encryptedPrivKeyBase64> <recipientPubKeyBase64>");
        //         return;
        //     }

        //     String encryptedAESKeyB64 = args[1];
        //     String password = args[2];
        //     String saltB64 = args[3];
        //     String encPrivB64 = args[4];
        //     String recipientPubB64 = args[5];

        //     // Derivar clave desde password+salt
        //     byte[] salt = Base64.getDecoder().decode(saltB64);
        //     byte[] passwordHash = pbkdf2(password.toCharArray(), salt, 200000, 256);
        //     SecretKeySpec passwordKey = new SecretKeySpec(passwordHash, "AES");

        //     // Descifrar clave privada del emisor
        //     byte[] encPrivBytes = Base64.getDecoder().decode(encPrivB64);
        //     byte[] privBytes = decryptAES(encPrivBytes, passwordKey);
        //     KeyFactory kf = KeyFactory.getInstance("RSA");
        //     PKCS8EncodedKeySpec privSpec = new PKCS8EncodedKeySpec(privBytes);
        //     PrivateKey priv = kf.generatePrivate(privSpec);

        //     // Descifrar la clave AES original (encrypted AES key bajo pubKey del emisor)
        //     byte[] encryptedAESKey = Base64.getDecoder().decode(encryptedAESKeyB64);
        //     Cipher rsaCipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
        //     rsaCipher.init(Cipher.DECRYPT_MODE, priv);
        //     byte[] aesKeyBytes = rsaCipher.doFinal(encryptedAESKey);

        //     // Cifrar la clave AES con la clave pública del destinatario
        //     byte[] recipientPubBytes = Base64.getDecoder().decode(recipientPubB64);
        //     X509EncodedKeySpec pubSpecRecipient = new X509EncodedKeySpec(recipientPubBytes);
        //     PublicKey recipientPub = kf.generatePublic(pubSpecRecipient);
        //     Cipher rsaCipher2 = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
        //     rsaCipher2.init(Cipher.ENCRYPT_MODE, recipientPub);
        //     byte[] reEncryptedAESKey = rsaCipher2.doFinal(aesKeyBytes);


        //     // Firma digital:

        //     String timestamp = generateTimestamp();
        //     String digitalSignatureB64 = signFile(reEncryptedAESKey, priv, timestamp);

        //     String jsonOutput = "{" +
        //             "\"aesKeyReEncrypted\":\"" + Base64.getEncoder().encodeToString(reEncryptedAESKey) + "\","
        //             + "\"firmaDigitalB64\":\"" + digitalSignatureB64 + "\","
        //             + "\"firmaTimestamp\":\"" + timestamp + "\""
        //             + "}";
        //     System.out.println(jsonOutput);
        //     return;
        // }
        if(mode.equals("share")){
            if (args.length != 8) {
                System.err.println(
                        "Usage: java prac1 send <encryptedFilePath> <User1password> <aesKeyEncrypted> <User2pubKey> <User1salt> <User1encPrivKey> <user1PubKey>");
                return;
            }

            String filePath = args[1];
            String user1Password = args[2];
            String aesKeyEncB64 = args[3];
            String user2PubB64 = args[4];
            String user1SaltB64 = args[5];
            String user1EncPrivB64 = args[6];
            String user1PubB64 = args[7];

            byte[] salt = Base64.getDecoder().decode(user1SaltB64);
            byte[] passwordHash = pbkdf2(user1Password.toCharArray(), salt, 200000, 256);
            SecretKeySpec passwordKey = new SecretKeySpec(passwordHash, "AES");

            byte[] encPrivBytes = Base64.getDecoder().decode(user1EncPrivB64);
            byte[] privBytes = decryptAES(encPrivBytes, passwordKey);
            KeyFactory kf = KeyFactory.getInstance("RSA");
            PKCS8EncodedKeySpec privSpec = new PKCS8EncodedKeySpec(privBytes);
            PrivateKey priv = kf.generatePrivate(privSpec);

            byte[] aesKeyEnc = Base64.getDecoder().decode(aesKeyEncB64);
            Cipher rsaCipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
            rsaCipher.init(Cipher.DECRYPT_MODE, priv);
            byte[] aesKeyBytes = rsaCipher.doFinal(aesKeyEnc);
            SecretKeySpec aesKey = new SecretKeySpec(aesKeyBytes, "AES");

            byte[] encryptedFile = readFileToBytes(filePath);

            byte[] user2PubBytes = Base64.getDecoder().decode(user2PubB64);
            X509EncodedKeySpec pubSpec = new X509EncodedKeySpec(user2PubBytes);
            PublicKey user2PubKey = kf.generatePublic(pubSpec);

            Cipher rsaEncrypt = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
            rsaEncrypt.init(Cipher.ENCRYPT_MODE, user2PubKey);
            byte[] aesKeyForUser2 = rsaEncrypt.doFinal(aesKeyBytes);

            //priv clave de user1
            String timestamp = generateTimestamp();
            String signatureB64 = signFile(encryptedFile, priv, timestamp);

            String jsonOutput = "{"
                + "\"encryptedAESKeyForUser2\":\"" + Base64.getEncoder().encodeToString(aesKeyForUser2) + "\","
                + "\"encryptedFile\":\"" + Base64.getEncoder().encodeToString(encryptedFile) + "\","
                + "\"signature\":\"" + signatureB64 + "\","
                + "\"timestamp\":\"" + timestamp + "\","
                + "\"senderPublicKey\":\"" + user1PubB64 + "\""
                + "}";

            System.out.println(jsonOutput);
            return;
        }
        if (mode.equals("receive")) {
            if (args.length != 9) {
                System.err.println(
                    "Usage: java prac1 receive <aesKeyEncrypted> <User2PrivKey> <signature> <timestamp> <user2Pass> <user2Salt> <encryptedFilePath> <user1Pub>");
                return;
            }

            String encAESKeyB64 = args[1];
            String user2PrivKeyB64 = args[2];
            String signatureB64 = args[3];
            String timestamp = args[4];
            String user2Password = args[5];
            String user2SaltB64 = args[6];
            String filePath = args[7];
            String user1PubB64 = args[8];

            byte[] salt = Base64.getDecoder().decode(user2SaltB64);
            byte[] passwordHash = pbkdf2(user2Password.toCharArray(), salt, 200000, 256);
            SecretKeySpec passwordKey = new SecretKeySpec(passwordHash, "AES");

            byte[] encPrivBytes = Base64.getDecoder().decode(user2PrivKeyB64);
            byte[] privBytes = decryptAES(encPrivBytes, passwordKey);
            KeyFactory kf = KeyFactory.getInstance("RSA");
            PrivateKey user2Priv = kf.generatePrivate(new PKCS8EncodedKeySpec(privBytes));

            byte[] encAESKey = Base64.getDecoder().decode(encAESKeyB64);
            Cipher rsaCipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
            rsaCipher.init(Cipher.DECRYPT_MODE, user2Priv);
            byte[] aesKeyBytes = rsaCipher.doFinal(encAESKey);
            SecretKeySpec aesKey = new SecretKeySpec(aesKeyBytes, "AES");

            byte[] encryptedFile = readFileToBytes(filePath);

            byte[] senderPubBytes = Base64.getDecoder().decode(user1PubB64);
            PublicKey senderPub = kf.generatePublic(new X509EncodedKeySpec(senderPubBytes));

            boolean valid = verifySign(senderPub, timestamp, signatureB64, encryptedFile);

            if (!valid) {
                System.out.println("{\"signatureValid\":false}");
                return;
            }

            byte[] decryptedBytes = decryptAES(encryptedFile, aesKey);

            String jsonOutput = "{"
                + "\"signatureValid\":true,"
                + "\"decryptedFile\":\"" + Base64.getEncoder().encodeToString(decryptedBytes) + "\""
                + "}";

            System.out.println(jsonOutput);
            return;
        }

        System.err.println("Invalid mode. Use: register | encrypt | decrypt | share");
    }
}
