<?php
// 2fa.php - Maneja la generación de QR y la verificación de códigos TOTP

require_once 'vendor/autoload.php'; 

use Endroid\QrCode\Builder\Builder;
use Endroid\QrCode\Encoding\Encoding;
use Endroid\QrCode\ErrorCorrectionLevel;
use Endroid\QrCode\RoundBlockSizeMode;
use Endroid\QrCode\Writer\PngWriter;

$ga = new PHPGangsta_GoogleAuthenticator(); 

// --- Configuración DB ---
$host = "localhost";
$usuario = "root";
$contrasena = "";
$base_datos = "cys";

$conn = new mysqli($host, $usuario, $contrasena, $base_datos);

if ($conn->connect_error) {
    die("ERROR_DB_CONNECTION:Error de conexión con la base de datos.");
}

$action = $_POST['action'] ?? 'none';
$username = $_POST['username'] ?? 'Usuario'; 
$user_id = $_POST['user_id'] ?? null; 

function getUserIdByUsername($conn, $username) {
    $stmt = $conn->prepare("SELECT user_id FROM usuario_credentials WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $stmt->close();
        return $row['user_id'];
    }
    $stmt->close();
    return null;
}

function getSecretByUserId($conn, $userId) {
    $stmt = $conn->prepare("SELECT two_factor_secret FROM usuario_credentials WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $stmt->close();
        return $row['two_factor_secret'];
    }
    $stmt->close();
    return null;
}

function updateSecretByUserId($conn, $userId, $secret) {
    $stmt = $conn->prepare("UPDATE usuario_credentials SET two_factor_secret = ? WHERE user_id = ?");
    $stmt->bind_param("si", $secret, $userId);
    $success = $stmt->execute();
    $stmt->close();
    return $success;
}

if ($action === 'generate') {
    $newSecret = $ga->createSecret();
    $appName = "CifradorApp";

    $otpUri = $ga->getQRCodeGoogleUrl($username, $newSecret, $appName);

    try {
        $result = Builder::create()
            ->writer(new PngWriter())
            ->writerOptions([])
            ->data($otpUri)
            ->encoding(new Encoding('UTF-8'))
            ->errorCorrectionLevel(ErrorCorrectionLevel::High)
            ->size(300)
            ->margin(10)
            ->roundBlockSizeMode(RoundBlockSizeMode::Margin)
            ->build();

        $dataUri = $result->getDataUri();
        echo "GENERATE_SUCCESS:{$newSecret}:{$dataUri}";

    } catch (\Exception $e) {
        echo "GENERATE_FAILURE:Error al generar el QR: " . $e->getMessage();
    }

} elseif ($action === 'verify') {
    $totpCode = $_POST['totp_code'] ?? '';
    $userIdInput = $_POST['user_id'] ?? '';

    if (empty($userIdInput) || empty($totpCode)) {
        echo "VERIFICATION_FAILURE:Faltan datos.";
        exit;
    }

    $secret = getSecretByUserId($conn, $userIdInput);

    if (empty($secret)) {
        echo "VERIFICATION_FAILURE:No hay secreto 2FA configurado.";
        exit;
    }

    // Validamos el código (ventana de tiempo de 2 bloques = 60 seg de margen)
    $checkResult = $ga->verifyCode($secret, $totpCode, 4);

    if ($checkResult) {
        // Código válido -> Iniciamos la sesión PHP real
        session_start();
        $_SESSION['user_id'] = $userIdInput;
        echo "VERIFICATION_SUCCESS:OK";
    } else {
        echo "VERIFICATION_FAILURE:Código inválido.";
    }

} elseif ($action === 'confirm_setup') {
    
    $submittedCode = $_POST['totp_code'] ?? '';
    $newSecret = $_POST['new_secret'] ?? '';
    $username = $_POST['username'] ?? ''; 
    
    $user_id_from_username = getUserIdByUsername($conn, $username);

    if (empty($user_id_from_username) || empty($submittedCode) || empty($newSecret)) {
        echo "CONFIRM_FAILURE:Faltan datos de configuración (o usuario no encontrado).";
        exit;
    }

    $checkResult = $ga->verifyCode($newSecret, $submittedCode, 1);

    if ($checkResult) {
        if (updateSecretByUserId($conn, $user_id_from_username, $newSecret)) {
             echo "CONFIRM_SUCCESS:2FA activado y verificado correctamente.";
        } else {
             echo "CONFIRM_FAILURE:Error al guardar el secreto en la base de datos.";
        }
    } else {
        echo "CONFIRM_FAILURE:Código de verificación incorrecto. Inténtalo de nuevo.";
    }

} else {
    http_response_code(400);
    echo "ERROR_INVALID_ACTION:Acción no válida.";
}

$conn->close();
?>