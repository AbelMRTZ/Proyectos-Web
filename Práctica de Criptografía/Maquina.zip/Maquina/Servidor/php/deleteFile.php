<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "cys";
header('Content-Type: application/json');

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) die(json_encode(["error" => "❌ Error conexión BD"]));

$file_id  = $_POST['file_id'] ?? null;
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

if (!$file_id || !$username || !$password) die(json_encode(["error" => "⚠️ Parámetros incompletos"]));

// Autenticar usuario (validar password derivando hash y comparando? Simplificamos: solo existencia usuario)
$stmt = $conn->prepare("SELECT user_id FROM usuario_credentials WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$u = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$u) die(json_encode(["error" => "❌ Usuario no existe"]));
$userId = $u['user_id'];

// Determinar propietario del archivo (registro único en user_files)
$stmt2 = $conn->prepare("SELECT user_id, encrypted_file_path FROM user_files WHERE file_id = ? LIMIT 1");
$stmt2->bind_param("i", $file_id);
$stmt2->execute();
$fileRow = $stmt2->get_result()->fetch_assoc();
$stmt2->close();
if (!$fileRow) die(json_encode(["error" => "❌ Archivo inexistente"]));

$ownerId = $fileRow['user_id'];
$path    = $fileRow['encrypted_file_path'];

if ($ownerId == $userId) {
    // El usuario es el propietario: eliminar archivo físico + registro + comparticiones
    if (file_exists($path) && !unlink($path)) {
        $fileDeleteWarning = "⚠️ No se pudo eliminar el archivo físico";
    }
    $delUF = $conn->prepare("DELETE FROM user_files WHERE file_id = ?");
    $delUF->bind_param("i", $file_id);
    if (!$delUF->execute()) die(json_encode(["error" => "❌ Error BD user_files: " . $delUF->error]));
    $delUF->close();

    // Eliminar todas las relaciones de compartición
    $delSF = $conn->prepare("DELETE FROM shared_files WHERE file_id = ?");
    $delSF->bind_param("i", $file_id);
    $delSF->execute();
    $delSF->close();
} else {
    // Usuario es receptor: sólo eliminar su relación en shared_files
    $delRel = $conn->prepare("DELETE FROM shared_files WHERE file_id = ? AND new_owner_id = ?");
    $delRel->bind_param("ii", $file_id, $userId);
    if (!$delRel->execute()) die(json_encode(["error" => "❌ Error BD shared_files: " . $delRel->error]));
    $delRel->close();
}

$conn->close();

$response = ["success" => true, "message" => "✅ Archivo eliminado"];
if (!empty($fileDeleteWarning)) $response['warning'] = $fileDeleteWarning;

echo json_encode($response);
?>