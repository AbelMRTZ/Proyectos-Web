<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "cys";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) die("❌ Error de conexión con la base de datos.");

$file_id  = $_POST['file_id'] ?? null;
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

if (!$file_id || !$username || !$password) die("⚠️ Faltan parámetros necesarios.");

// ------------------------------
// Obtener las claves del usuario
// ------------------------------
$stmt = $conn->prepare("SELECT user_id, salt, encrypted_private_key, public_key FROM usuario_credentials WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) die("❌ Usuario no encontrado.");

$user_id    = $user['user_id'];
$saltB64    = $user['salt'];
$encPrivB64 = $user['encrypted_private_key'];
$pubKeyB64  = $user['public_key'];

// ------------------------------
// Buscar el archivo asociado al usuario
// ------------------------------
$stmt2 = $conn->prepare("
    SELECT file_name, encrypted_file_path, aes_key_encrypted
    FROM user_files
    WHERE file_id = ? AND user_id = ?
");
$stmt2->bind_param("ii", $file_id, $user_id);
$stmt2->execute();
$file = $stmt2->get_result()->fetch_assoc();
$stmt2->close();

if (!$file) die("❌ Archivo no encontrado.");

// ------------------------------
// Verificar que el archivo cifrado exista
// ------------------------------
$encryptedFilePath = $file['encrypted_file_path'];
if (!file_exists($encryptedFilePath)) {
    die("❌ El archivo cifrado no existe en la ruta especificada: " . htmlspecialchars($encryptedFilePath));
}

// ------------------------------
// Ejecutar el proceso de desencriptado con Java
// ------------------------------
$cmd = "java -cp ../../Local/app prac1 decrypt " .
    escapeshellarg($encryptedFilePath) . " " .
    escapeshellarg($password) . " " .
    escapeshellarg($file['aes_key_encrypted']) . " " .
    escapeshellarg($pubKeyB64) . " " .
    escapeshellarg($saltB64) . " " .
    escapeshellarg($encPrivB64) . " 2>&1";

$output = shell_exec($cmd);
$data = json_decode($output, true);

if (!$data || !isset($data['decryptedFile'])) {
    die("❌ Error al desencriptar el archivo: " . htmlspecialchars($output));
}

// ------------------------------
// Guardar el archivo desencriptado en “Archivos Descargados”
// ------------------------------
$userDownloadDir = "../../Local/Usuarios/" . $username . "/Archivos Descargados";
if (!is_dir($userDownloadDir)) {
    mkdir($userDownloadDir, 0755, true);
}

$savePath = $userDownloadDir . "/" . $file['file_name'];
if (file_put_contents($savePath, base64_decode($data['decryptedFile'])) === false) {
    die("❌ No se pudo guardar el archivo en 'Archivos Descargados'.");
}

// ------------------------------
// Responder con JSON de éxito
// ------------------------------
echo json_encode([
    "success" => true,
    "message" => "✅ Archivo desencriptado correctamente y guardado en 'Archivos Descargados'.",
    "file_name" => $file['file_name'],
    "saved_path" => $savePath
]);

$conn->close();
?>
