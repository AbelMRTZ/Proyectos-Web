<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "cys";

header('Content-Type: application/json');

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) die(json_encode(["error" => "❌ Error BD"]));

$file_id  = $_POST['file_id'] ?? null;
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

if (!$file_id || !$username || !$password) {
    die(json_encode(["error" => "⚠️ Faltan parámetros"]));
}

// ------------------------------
// Datos del usuario receptor
// ------------------------------
$stmt = $conn->prepare("
    SELECT user_id, salt, encrypted_private_key, public_key
    FROM usuario_credentials
    WHERE username = ?
");
$stmt->bind_param("s", $username);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) die(json_encode(["error" => "❌ Usuario no encontrado"]));

$user_id    = $user["user_id"];
$saltB64    = $user["salt"];
$privEncB64 = $user["encrypted_private_key"];
$pubUserB64 = $user["public_key"];

// ------------------------------
// Datos del archivo compartido
// ------------------------------
$stmt2 = $conn->prepare("
    SELECT sf.id AS shared_id,
           sf.file_path AS original_path,
           sf.aes_key_encrypted_new_owner,
           sf.firmaDigitalB64,
           sf.firmaTimestamp,
           u.public_key AS sender_pub,
           uf.file_name
    FROM shared_files sf
    JOIN user_files uf ON uf.file_id = sf.file_id
    JOIN usuario_credentials u ON u.user_id = sf.original_owner_id
    WHERE sf.file_id = ? AND sf.new_owner_id = ?
");
$stmt2->bind_param("ii", $file_id, $user_id);
$stmt2->execute();
$file = $stmt2->get_result()->fetch_assoc();
$stmt2->close();

if (!$file) die(json_encode(["error" => "❌ No tienes acceso a este archivo compartido"]));

$originalPath = $file["original_path"];
if (!file_exists($originalPath)) {
    die(json_encode(["error" => "❌ Archivo físico no existe"]));
}

// Leer archivo cifrado en Base64

// ------------------------------
// Ejecutar Java modo RECEIVE
// ------------------------------
$cmd = "java -cp ../../Local/app prac1 receive "
    . escapeshellarg($file["aes_key_encrypted_new_owner"]) . " "
    . escapeshellarg($privEncB64) . " "
    . escapeshellarg($file["firmaDigitalB64"]) . " "
    . escapeshellarg($file["firmaTimestamp"]) . " "
    . escapeshellarg($password) . " "
    . escapeshellarg($saltB64) . " "
    . escapeshellarg($originalPath) . " "
    . escapeshellarg($file["sender_pub"]) . " 2>&1";



$out = shell_exec($cmd);
$data = json_decode($out, true);


if (!$data) {
    die(json_encode(["error" => "❌ Java devolvió error", "raw" => $out]));
}
if (!$data["signatureValid"]) {
    die(json_encode(["error" => "❌ Firma digital no válida"]));
}

// ------------------------------
// Guardar archivo en carpeta del receptor
// ------------------------------
$downloadDir = "../../Local/Usuarios/$username/Archivos Descargados";
if (!is_dir($downloadDir)) mkdir($downloadDir, 0755, true);

$savePath = $downloadDir . "/" . $file["file_name"];
file_put_contents($savePath, base64_decode($data["decryptedFile"]));

// ------------------------------
// Marcar download = 1 y actualizar path
// ------------------------------
$stmt3 = $conn->prepare("
    UPDATE shared_files 
    SET download = 1, file_path = ? 
    WHERE id = ?
");
$stmt3->bind_param("si", $savePath, $file["shared_id"]);
$stmt3->execute();
$stmt3->close();

// ------------------------------
// Respuesta JSON
// ------------------------------
echo json_encode([
    "success" => true,
    "message" => "Archivo compartido validado y desencriptado correctamente.",
    "file_name" => $file["file_name"],
    "saved_path" => $savePath
]);

$conn->close();
