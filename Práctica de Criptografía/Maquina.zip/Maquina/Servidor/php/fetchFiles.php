<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "cys";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) die(json_encode(["error" => "❌ Error de conexión con la base de datos."]));

$username = $_POST['username'] ?? '';
if (empty($username)) die(json_encode(["error" => "⚠️ Falta el nombre de usuario."]));

// Buscar ID del usuario
$stmt = $conn->prepare("SELECT user_id FROM usuario_credentials WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 0) {
    die(json_encode(["error" => "❌ Usuario no encontrado."]));
}

$user = $res->fetch_assoc();
$user_id = $user['user_id'];
$stmt->close();

// Obtener SOLO archivos originales del usuario (excluir los que fueron recibidos vía compartición)
// Definición: un archivo recibido aparece en shared_files con new_owner_id = user_id.
// Por tanto, excluimos aquellos file_id que estén en esa condición.
$stmt2 = $conn->prepare("SELECT uf.file_id, uf.file_name, uf.created_at
                                                 FROM user_files uf
                                                 WHERE uf.user_id = ?
                                                     AND NOT EXISTS (SELECT 1 FROM shared_files sf WHERE sf.file_id = uf.file_id AND sf.new_owner_id = uf.user_id)
                                                 ORDER BY uf.created_at DESC");
$stmt2->bind_param("i", $user_id);
$stmt2->execute();
$result = $stmt2->get_result();

$files = [];
while ($row = $result->fetch_assoc()) {
    $files[] = $row;
}

$stmt2->close();
$conn->close();

header("Content-Type: application/json");
echo json_encode($files);
?>
