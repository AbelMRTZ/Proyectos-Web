<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "cys";
header('Content-Type: application/json');

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) die(json_encode(["error" => "❌ Error conexión BD"]));

$username = $_POST['username'] ?? '';
if (!$username) die(json_encode(["error" => "⚠️ Falta username"]));

// Obtener user_id
$stmt = $conn->prepare("SELECT user_id FROM usuario_credentials WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$u = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$u) die(json_encode(["error" => "❌ Usuario no existe"]));
$userId = $u['user_id'];

// Verificar existencia de shared_files
$hasShared = $conn->query("SHOW TABLES LIKE 'shared_files'")->num_rows === 1;
if (!$hasShared) {
    echo json_encode([]); // sin tabla -> no compartidos
    $conn->close();
    exit;
}

$sql = "SELECT sf.file_id, uf.file_name, uf.encrypted_file_path, u.username AS original_owner_username, sf.aes_key_encrypted_new_owner
    FROM shared_files sf
    JOIN user_files uf ON sf.file_id = uf.file_id
    JOIN usuario_credentials u ON sf.original_owner_id = u.user_id
    WHERE sf.new_owner_id = ?";

$stmt2 = $conn->prepare($sql);
$stmt2->bind_param("i", $userId);
$stmt2->execute();
$res = $stmt2->get_result();
$shared = [];
while ($row = $res->fetch_assoc()) {
    $shared[] = [
        "file_id" => $row['file_id'],
        "file_name" => $row['file_name'],
        "encrypted_file_path" => $row['encrypted_file_path'],
        "original_owner_username" => $row['original_owner_username'],
        "aes_key_encrypted" => $row['aes_key_encrypted_new_owner']
    ];
}
$stmt2->close();
$conn->close();

echo json_encode($shared);
?>