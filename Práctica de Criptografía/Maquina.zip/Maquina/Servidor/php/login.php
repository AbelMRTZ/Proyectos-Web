<?php
// login.php — Unificacion: Valida usuario/pass y decide si pedir 2FA o iniciar sesion

header('Content-Type: text/plain; charset=utf-8');

$host = "localhost";
$usuario = "root";
$contrasena = "";
$base_datos = "cys";

$conn = new mysqli($host, $usuario, $contrasena, $base_datos);
if ($conn->connect_error) {
    die("❌ Error de conexión con la base de datos: " . $conn->connect_error);
}

// obtener datos del formulario
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

if (empty($username) || empty($password)) {
    die("⚠️ Faltan el nombre de usuario o la contraseña.");
}


$stmt = $conn->prepare("SELECT user_id, password_hash, salt, two_factor_secret FROM usuario_credentials WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "❌ Usuario o contraseña incorrectos.";
    exit;
}

$row = $result->fetch_assoc();
$stmt->close();

$stored_user_id = $row['user_id'];
$stored_hash = base64_decode($row['password_hash']);
$stored_salt = base64_decode($row['salt']);
$two_factor_secret = $row['two_factor_secret'];

// Calcular hash PBKDF2
$iteraciones = 200000;
$longitud_clave = 32;
$hash_calculado = hash_pbkdf2("sha256", $password, $stored_salt, $iteraciones, $longitud_clave, true);

if (!hash_equals($stored_hash, $hash_calculado)) {
    echo "❌ Usuario o contraseña incorrectos.";
    exit;
}


if (!empty($two_factor_secret)) {
    // tiene 2 FA activado
    echo "2FA_REQUIRED:" . $stored_user_id . ":" . $username;
} else {
    // no tiene 2FA activado
    session_start();
    $_SESSION['user_id'] = $stored_user_id;
    echo "✅ Inicio de sesión correcto.";
}

$conn->close();
?>