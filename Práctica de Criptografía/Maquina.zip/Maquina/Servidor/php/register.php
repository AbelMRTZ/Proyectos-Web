<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "cys";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("❌ Error de conexión con la base de datos: " . $conn->connect_error);
}

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

if (empty($username) || empty($password)) {
    die("⚠️ Faltan el nombre de usuario o la contraseña.");
}

// ------------------------------
// Preparar rutas de carpetas
// ------------------------------
$dirs = [
    "../../Servidor/Usuarios/" . $username,
    "../../Local/Usuarios/" . $username,
    "../../Local/Usuarios/" . $username . "/Archivos",
    "../../Local/Usuarios/" . $username . "/Archivos Descargados"
];
$created = []; // para hacer rollback

// ------------------------------
// Verificar si el nombre de usuario ya existe
// ------------------------------
$stmt = $conn->prepare("SELECT user_id FROM usuario_credentials WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    $stmt->close();
    die("⚠️ El nombre de usuario ya existe. Por favor, elige otro.");
}
$stmt->close();

// ------------------------------
// Crear carpetas del usuario con rollback si falla
// ------------------------------
$folderError = false;

foreach ($dirs as $dir) {
    if (!file_exists($dir)) {
        if (!mkdir($dir, 0755, true)) {
            $folderError = true;
            $errorMsg = "❌ No se pudo crear la carpeta '$dir'. Registro cancelado.";
            break;
        }
        $created[] = $dir;
    }
}

if ($folderError) {
    // rollback carpetas creadas
    for ($i = count($created) - 1; $i >= 0; $i--) {
        if (is_dir($created[$i])) rmdir($created[$i]);
    }
    die($errorMsg);
}

// ------------------------------
// Ejecutar Java en modo registro
// ------------------------------
$passwordEscaped = escapeshellarg($password);
$javaCmd = "java -cp ../../Local/app prac1 register $passwordEscaped 2>&1";
$javaOutput = shell_exec($javaCmd);

$data = json_decode($javaOutput, true);
if (
    !$data ||
    !isset($data['salt'], $data['passwordHash'], $data['encryptedPrivateKey'], $data['publicKey'])
) {
    // borrar carpetas si Java falla
    for ($i = count($created) - 1; $i >= 0; $i--) {
        if (is_dir($created[$i])) rmdir($created[$i]);
    }
    die("❌ Salida inválida del proceso Java: " . htmlspecialchars($javaOutput));
}

// Extraer datos generados por Java
$saltB64 = $data['salt'];
$passwordHashB64 = $data['passwordHash'];
$encryptedPrivKeyB64 = $data['encryptedPrivateKey'];
$publicKeyB64 = $data['publicKey'];

// ------------------------------
// Insertar en la base de datos
// ------------------------------
$stmt2 = $conn->prepare("
    INSERT INTO usuario_credentials (username, password_hash, salt, encrypted_private_key, public_key)
    VALUES (?, ?, ?, ?, ?)
");
if (!$stmt2) {
    // rollback folders if DB prepare fails
    for ($i = count($created) - 1; $i >= 0; $i--) {
        if (is_dir($created[$i])) rmdir($created[$i]);
    }
    die("❌ Error al preparar la consulta SQL.");
}

$stmt2->bind_param("sssss", $username, $passwordHashB64, $saltB64, $encryptedPrivKeyB64, $publicKeyB64);
if (!$stmt2->execute()) {
    // rollback folders if insert fails
    for ($i = count($created) - 1; $i >= 0; $i--) {
        if (is_dir($created[$i])) rmdir($created[$i]);
    }
    die("❌ Error al guardar el usuario en la base de datos: " . $stmt2->error);
}
$stmt2->close();

echo "✅ Registro exitoso para el usuario '" . htmlspecialchars($username) . "'.";

$conn->close();
?>
