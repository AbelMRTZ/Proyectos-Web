<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "cys";

header('Content-Type: application/json');

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) die(json_encode(["error" => "❌ Error de conexión BD"]));

$file_id        = $_POST['file_id'] ?? null;
$sourceUsername = $_POST['source_username'] ?? '';
$targetUsername = $_POST['target_username'] ?? '';
$password       = $_POST['password'] ?? '';

if (!$file_id || !$sourceUsername || !$targetUsername || !$password) {
    die(json_encode(["error" => "⚠️ Parámetros incompletos."]));
}
if ($sourceUsername === $targetUsername) {
    die(json_encode(["error" => "⚠️ No puedes compartir contigo mismo."]));
}

// Obtener datos del usuario origen
$stmt = $conn->prepare("SELECT user_id, salt, encrypted_private_key, public_key FROM usuario_credentials WHERE username = ?");
$stmt->bind_param("s", $sourceUsername);
$stmt->execute();
$sourceUser = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$sourceUser) die(json_encode(["error" => "❌ Usuario origen no encontrado."]));

// Obtener datos del usuario destino
$stmt2 = $conn->prepare("SELECT user_id, public_key FROM usuario_credentials WHERE username = ?");
$stmt2->bind_param("s", $targetUsername);
$stmt2->execute();
$targetUser = $stmt2->get_result()->fetch_assoc();
$stmt2->close();
if (!$targetUser) die(json_encode(["error" => "❌ Usuario destino no existe."]));

$sourceUserId = $sourceUser['user_id'];
$targetUserId = $targetUser['user_id'];

// Verificar que el archivo pertenece al usuario origen
$stmt3 = $conn->prepare("SELECT file_name, encrypted_file_path, aes_key_encrypted FROM user_files WHERE file_id = ? AND user_id = ?");
$stmt3->bind_param("ii", $file_id, $sourceUserId);
$stmt3->execute();
$fileRow = $stmt3->get_result()->fetch_assoc();
$stmt3->close();
if (!$fileRow) die(json_encode(["error" => "❌ Archivo no pertenece al usuario o no existe."]));

$fileName = $fileRow['file_name'];
$oldPath  = $fileRow['encrypted_file_path'];
$encryptedAESForSource = $fileRow['aes_key_encrypted'];

if (!file_exists($oldPath)) die(json_encode(["error" => "❌ Archivo físico no encontrado en disco."]));

// Mantener archivo físico en carpeta del owner para conservarlo intacto.
// Se comparte sólo la clave re-encriptada y el file_id mediante shared_files.

// Comprobar si ya existe una compartición del archivo con ese usuario destino
$stmtCheck = $conn->prepare("
    SELECT id FROM shared_files 
    WHERE file_id = ? 
      AND original_owner_id = ? 
      AND new_owner_id = ?
");
$stmtCheck->bind_param("iii", $file_id, $sourceUserId, $targetUserId);
$stmtCheck->execute();
$existing = $stmtCheck->get_result()->fetch_assoc();
$stmtCheck->close();

if ($existing) {
    die(json_encode([
        "error" => "⚠️ Este archivo ya está compartido con el usuario destino.",
        "id" => $existing['id']
    ]));
}


// Re-encriptar clave AES usando modo share (Java).
// Nota: la clave AES del archivo original se re-cifra para el destinatario.
$cmd = "java -cp ../../Local/app prac1 share " .
    escapeshellarg($oldPath) . " " .
    escapeshellarg($password) . " " .
    escapeshellarg($encryptedAESForSource) . " " .
    escapeshellarg($targetUser['public_key']) . " " .
    escapeshellarg($sourceUser['salt']) . " " .
    escapeshellarg($sourceUser['encrypted_private_key']) . " " .
    escapeshellarg($targetUser['public_key']) . " 2>&1";

$javaOut = shell_exec($cmd);
$javaJson = json_decode($javaOut, true);
if (!$javaJson || !isset($javaJson['encryptedAESKeyForUser2'])) {
    // intentar revertir movimiento si falla
    // @rename($newPath, $oldPath);
    die(json_encode(["error" => "❌ Falló re-encriptación: " . $javaOut]));
}

/* Obtención de datos */
$newEncryptedAES = $javaJson['encryptedAESKeyForUser2'];
$firmaDigitalB64 = $javaJson['signature'];
$firmaTimestamp = $javaJson['timestamp'];
$download = 0;
// Ya no se modifica user_files: archivo permanece con owner.

// Insertar enlace de compartición en shared_files incluyendo AES re-encriptada para el destinatario
// Necesita columna aes_key_encrypted_new_owner; si no existe se intentará igualmente (el INSERT fallará y se informa)
$stmtLink = $conn->prepare("INSERT INTO shared_files (file_id, original_owner_id, new_owner_id, aes_key_encrypted_new_owner, download, file_path, firmaDigitalB64, firmaTimestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

if (!$stmtLink) {
    die(json_encode(["error" => "❌ Error preparando INSERT enlace compartido (verifique estructura tabla shared_files): " . $conn->error]));
}
$stmtLink->bind_param("iiisisss", $file_id, $sourceUserId, $targetUserId, $newEncryptedAES, $download, $oldPath, $firmaDigitalB64, $firmaTimestamp);
if (!$stmtLink->execute()) {
    die(json_encode(["error" => "❌ Error BD al crear enlace compartido: " . $stmtLink->error]));
}
$sharedId = $stmtLink->insert_id;
$stmtLink->close();

// (Opcional) registrar historial en tabla shared_files si existe
// Historial ya cubierto por el propio registro shared_files (sharedId)

$conn->close();

echo json_encode([
    "success" => true,
    "message" => "✅ Archivo compartido correctamente con " . $targetUsername,
    "path" => $oldPath,
    "file_id" => $file_id,
    "shared_id" => $sharedId
]);
?>