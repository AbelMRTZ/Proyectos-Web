<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "cys";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) die("❌ Error de conexión con la base de datos: " . $conn->connect_error);

// -------------------------------

if (!isset($_FILES['file'])) die("⚠️ No se recibió ningún archivo.");

$file_name = $_FILES['file']['name'];
$file_tmp  = $_FILES['file']['tmp_name'];
$username  = $_POST['username'] ?? '';
$password  = $_POST['password'] ?? '';

if (empty($username) || empty($password)) die("⚠️ Falta el nombre de usuario o la contraseña.");

// Buscar las claves del usuario
$stmt = $conn->prepare("SELECT user_id, public_key, salt, encrypted_private_key FROM usuario_credentials WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) die("❌ Usuario no encontrado. Por favor, inicia sesión primero.");
$user = $result->fetch_assoc();
$stmt->close();

// Ejecutar el proceso de Java para encriptar el archivo
$fileEscaped = escapeshellarg($file_tmp);
$passwordEscaped = escapeshellarg($password);
$pubEscaped = escapeshellarg($user['public_key']);
$saltEscaped = escapeshellarg($user['salt']);
$encPrivEscaped = escapeshellarg($user['encrypted_private_key']);

// Comando Java: modo "encrypt"
$javaCommand = "java -cp ../../Local/app prac1 encrypt $fileEscaped $passwordEscaped $pubEscaped $saltEscaped $encPrivEscaped 2>&1";
$javaOutput = shell_exec($javaCommand);

    

$data = json_decode($javaOutput, true);
if (!$data) die("❌ No se pudo interpretar la salida JSON de Java: " . $javaOutput);

// Añades Firma
$signature = $data['firmaDigitalB64'] ?? null;
$tsFirma = $data['firmaTimestamp'] ?? null;


$encryptedFilePath = "../../Servidor/Usuarios/" . $username . "/" . $file_name . '.enc';
if (file_put_contents($encryptedFilePath, base64_decode($data['encryptedFile'])) === false) {
    die("❌ No se pudo guardar el archivo cifrado en disco.");
}

// Guardar el archivo en la base de datos
// 🔹 AÑADIDO: incluir la firma digital en el INSERT
$stmt2 = $conn->prepare("
    INSERT INTO user_files (user_id, file_name, encrypted_file_path, aes_key_encrypted, firmaDigitalB64, firmaTimestamp)
    VALUES (?, ?, ?, ?, ?, ?)
");
$stmt2->bind_param("isssss", $user['user_id'], $file_name, $encryptedFilePath, $data['aesKey'], $signature, $tsFirma);
if (!$stmt2->execute()) die("❌ Error al guardar en la base de datos: " . $stmt2->error);
$stmt2->close();

echo "✅ Archivo encriptado y almacenado correctamente para el usuario '$username'.";
$conn->close();
?>
