<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "cys";
header('Content-Type: application/json');

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) die(json_encode(["error" => "❌ Error conexión BD"]));

// Obtener todos los usernames

$result = $conn->query("SELECT username FROM usuario_credentials");

$usernames = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $usernames[] = $row['username'];
    }
}

$conn->close();

echo json_encode(["success" => true, "usernames" => $usernames]);
?>